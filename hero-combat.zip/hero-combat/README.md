# ⚔ Apex Hero Arena

Game đấu tướng 3D (Three.js + PeerJS). Chế độ: 1v1, 2v2, 3v3, Hỗn Chiến. 4 tướng: Hiệp Sĩ, Pháp Sư, Sát Thủ, Thầy Tế (mỗi tướng 3 skill + ULT + nội tại).

## Chạy trên điện thoại (không cần PC)
1. Upload toàn bộ nội dung thư mục `www/` lên repo GitHub (đặt ở thư mục gốc hoặc `docs/`).
2. Repo → **Settings → Pages** → Deploy from branch → chọn `main` và thư mục `/ (root)` hoặc `/docs`.
3. Mở link `https://<user>.github.io/<repo>/` bằng Chrome/Safari.

## Chơi
- **Offline**: bấm "Chơi Offline" → bot lấp đầy đội.
- **Online**: một người bấm "Tạo phòng", gửi mã 5 số; người khác nhập mã → "Vào phòng". Chủ phòng bấm "Bắt đầu" (chỗ trống do bot lấp). Cần HTTPS + internet (PeerJS cloud để bắt tay WebRTC).

## Điều khiển
- Điện thoại: joystick trái, nút phải (Đánh, S1, S2, S3, ULT). Tự nhắm kẻ địch gần nhất.
- PC: WASD di chuyển, chuột nhắm, Click/Space = đánh, Q/E/R = skill, F = ULT.

## Kiến trúc
Host là trọng tài tính sát thương, client gửi vị trí/skill; host phát lại cho mọi người (mô hình sao qua PeerJS).
