import { HEROES } from './hero_classes.js';

export const MODES = {
  '1v1': { label: '1v1', teams: 2, per: 1, kills: 5, time: 150 },
  '2v2': { label: '2v2', teams: 2, per: 2, kills: 15, time: 240 },
  '3v3': { label: '3v3', teams: 2, per: 3, kills: 25, time: 300 },
  'ffa': { label: 'Hỗn Chiến', teams: 0, total: 6, kills: 10, time: 240 }
};
export const TEAM_COLORS = [0x3b82f6, 0xef4444, 0x22c55e, 0xeab308, 0xa855f7, 0xf97316];
const TEAM_NAMES = ['Xanh', 'Đỏ'];

// Xếp người chơi thật + bot vào đội và vị trí xuất phát
export function assign(key, humans) {
  const M = MODES[key], total = M.teams ? M.teams * M.per : M.total;
  const keys = Object.keys(HEROES), out = [], cnt = {};
  for (let i = 0; i < total; i++) {
    const h = humans[i], team = M.teams ? i % M.teams : i;
    const n = cnt[team] = (cnt[team] || 0) + 1, idx = n - 1;
    let x, z;
    if (M.teams) { x = team === 0 ? -16 : 16; z = (idx - (M.per - 1) / 2) * 5; }
    else { const a = (i / total) * Math.PI * 2; x = Math.cos(a) * 15; z = Math.sin(a) * 15; }
    const info = h ? { id: h.id, name: h.name, hero: h.hero, bot: false }
      : { id: 'bot' + i, name: 'Bot ' + (i + 1), hero: keys[i % keys.length], bot: true };
    out.push({ ...info, team, x, z });
  }
  return out;
}

export function teamLabel(G, t) {
  if (MODES[G.mode].teams) return 'Đội ' + TEAM_NAMES[t];
  const p = [...G.players.values()].find(x => x.team == t);
  return p ? p.name : '?';
}

export function registerKill(G, v, s) {
  G.stats[v.id][1]++;
  if (s && s.team !== v.team) { G.stats[s.id][0]++; G.score[s.team] = (G.score[s.team] || 0) + 1; }
}

// Trả về chuỗi người thắng hoặc null nếu chưa kết thúc
export function checkEnd(G) {
  const M = MODES[G.mode];
  let best = -1, bt = null, tie = false;
  for (const t in G.score) {
    const v = G.score[t];
    if (v > best) { best = v; bt = Number(t); tie = false; } else if (v === best) tie = true;
  }
  if (best >= M.kills && !tie) return teamLabel(G, bt) + ' chiến thắng!';
  if (G.time <= 0) return tie ? 'Hòa!' : teamLabel(G, bt) + ' chiến thắng!';
  return null;
}

export function scoreText(G) {
  const M = MODES[G.mode];
  if (M.teams) return `Xanh ${G.score[0] || 0} : ${G.score[1] || 0} Đỏ (đến ${M.kills})`;
  const me = G.me && G.stats[G.me.id] ? G.stats[G.me.id][0] : 0;
  const top = Math.max(0, ...Object.values(G.score));
  return `Bạn ${me} hạ · Dẫn đầu ${top}/${M.kills}`;
}
