import * as THREE from 'three';
import { HEROES } from './hero_classes.js';

const BOX = new THREE.BoxGeometry(0.18, 0.18, 0.18);
const SPH = new THREE.SphereGeometry(1, 12, 10);
const RING = new THREE.RingGeometry(0.85, 1, 40);

// Sát thương chỉ được tính trên "host" (G.auth). Mọi máy đều chạy hiệu ứng.
export class Combat {
  constructor(G) { this.G = G; this.proj = []; this.fx = []; this.mats = {}; this.ac = null; }

  mat(c) { return this.mats[c] || (this.mats[c] = new THREE.MeshBasicMaterial({ color: c })); }

  sfx(k) {
    try {
      const A = this.ac || (this.ac = new (window.AudioContext || window.webkitAudioContext)());
      if (A.state === 'suspended') A.resume();
      const P = {
        melee: [300, 90, .12, 'sawtooth'], projectile: [600, 200, .15, 'square'],
        dash: [200, 700, .2, 'sawtooth'], aoe: [120, 40, .4, 'triangle'],
        buff: [400, 800, .25, 'sine'], heal: [500, 900, .3, 'sine'], hit: [180, 60, .1, 'square']
      }[k] || [300, 100, .1, 'sine'];
      const o = A.createOscillator(), g = A.createGain(), t = A.currentTime;
      o.type = P[3];
      o.frequency.setValueAtTime(P[0], t);
      o.frequency.exponentialRampToValueAtTime(P[1], t + P[2]);
      g.gain.setValueAtTime(0.1, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + P[2]);
      o.connect(g); g.connect(A.destination);
      o.start(t); o.stop(t + P[2]);
    } catch (e) { /* audio không khả dụng */ }
  }

  burst(pos, color, n = 10, sp = 5) {
    if (this.fx.length > 320) return;
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(BOX, this.mat(color));
      m.position.set(pos.x, 1, pos.z);
      const a = Math.random() * 6.283, u = Math.random() * sp;
      this.fx.push({ m, k: 'p', vx: Math.cos(a) * u, vy: 2 + Math.random() * sp, vz: Math.sin(a) * u, life: 0.5 + Math.random() * 0.3 });
      this.G.scene.add(m);
    }
  }

  ring(x, z, color, r, dur = 0.4) {
    const m = new THREE.Mesh(RING, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
    m.rotation.x = -Math.PI / 2; m.position.set(x, 0.1, z); m.scale.setScalar(0.1);
    this.G.scene.add(m);
    this.fx.push({ m, k: 'r', life: dur, max: dur, r });
  }

  enemies(p) { return [...this.G.players.values()].filter(t => t.alive && t.team !== p.team); }

  cast(p, i, dx, dz) {
    const G = this.G, H = HEROES[p.hero], s = H.skills[i], col = H.color;
    const l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l;
    p.cd[i] = s.cd; p.face = Math.atan2(dx, dz); p.swing = 0.25;
    const px = p.pos.x, pz = p.pos.z, host = G.auth;
    this.sfx(s.type);

    if (s.type === 'melee') {
      this.ring(px + dx * 1.5, pz + dz * 1.5, col, s.range * 0.6, 0.25);
      this.burst({ x: px + dx * 2, z: pz + dz * 2 }, col, 6, 3);
      if (host) for (const t of this.enemies(p)) {
        const ox = t.pos.x - px, oz = t.pos.z - pz, d = Math.hypot(ox, oz) || 1;
        if (d <= s.range + 0.5 && (ox * dx + oz * dz) / d > Math.cos(s.arc / 2)) this.damage(p, t, s.dmg, s, ox / d, oz / d);
      }
    } else if (s.type === 'projectile') {
      const n = s.count || 1;
      for (let k = 0; k < n; k++) {
        const a = (k - (n - 1) / 2) * (s.spread || 0), c = Math.cos(a), sn = Math.sin(a);
        const vx = dx * c - dz * sn, vz = dx * sn + dz * c;
        const m = new THREE.Mesh(SPH, this.mat(s.color || col));
        m.scale.setScalar(s.radius); m.position.set(px + vx, 1.2, pz + vz);
        G.scene.add(m);
        this.proj.push({ m, o: p, s, vx, vz, life: s.life });
      }
    } else if (s.type === 'dash') {
      p.dash = { t: s.dist / s.speed, vx: dx * s.speed, vz: dz * s.speed, nx: dx, nz: dz, sk: s, hit: new Set() };
      this.ring(px, pz, col, 2, 0.3);
    } else if (s.type === 'aoe') {
      const cx = px + dx * (s.offset || 0), cz = pz + dz * (s.offset || 0);
      const run = () => {
        this.ring(cx, cz, col, s.radius, 0.5);
        this.burst({ x: cx, z: cz }, col, s.ult ? 30 : 14, s.radius);
        this.sfx('aoe');
        if (!G.auth) return;
        for (const t of this.enemies(p)) {
          const ox = t.pos.x - cx, oz = t.pos.z - cz, d = Math.hypot(ox, oz) || 1;
          if (d <= s.radius + 0.5) this.damage(p, t, s.dmg, s, ox / d, oz / d);
        }
      };
      if (s.delay) { this.ring(cx, cz, 0xff3333, s.radius, s.delay); setTimeout(() => { if (G.running) run(); }, s.delay * 1000); }
      else run();
    } else if (s.type === 'buff') {
      p.buff = { speed: s.speed || 1, t: s.dur };
      if (s.shield) { p.shield = s.shield; p.shieldT = s.dur; }
      this.ring(px, pz, col, 2, 0.5);
    } else if (s.type === 'heal') {
      this.ring(px, pz, 0x69f0ae, s.radius, 0.6);
      this.burst(p.pos, 0x69f0ae, 16, s.radius);
      if (host) for (const t of G.players.values()) {
        if (!t.alive) continue;
        const ox = t.pos.x - px, oz = t.pos.z - pz, d = Math.hypot(ox, oz) || 1;
        if (d > s.radius) continue;
        if (t.team === p.team) this.heal(t, s.amount);
        else if (s.dmg) this.damage(p, t, s.dmg, s, ox / d, oz / d);
      }
    }
  }

  heal(t, n) {
    if (!t.alive) return;
    t.hp = Math.min(t.maxhp, t.hp + n);
    const m = { t: 'hit', id: t.id, hp: Math.round(t.hp), dmg: -n, stun: 0, kx: 0, kz: 0 };
    if (this.G.net) this.G.net.bcast(m);
    this.applyHit(m);
  }

  damage(src, t, dmg, s, dx, dz) {
    const G = this.G;
    if (!G.auth || !t.alive) return;
    let a = dmg * (1 - (HEROES[t.hero].dr || 0));
    if (t.shield > 0) { const b = Math.min(t.shield, a); t.shield -= b; a -= b; }
    t.hp = Math.max(0, t.hp - a);
    const m = { t: 'hit', id: t.id, hp: Math.round(t.hp), dmg: Math.round(a), stun: s.stun || 0, kx: dx * (s.knock || 0), kz: dz * (s.knock || 0), sid: src.id };
    const ls = HEROES[src.hero].ls;
    if (ls && a > 0) { src.hp = Math.min(src.maxhp, src.hp + a * ls); m.shp = Math.round(src.hp); }
    if (G.net) G.net.bcast(m);
    this.applyHit(m);
    if (t.hp <= 0) G.kill(t, src);
  }

  applyHit(m) {
    const t = this.G.players.get(m.id);
    if (!t) return;
    t.hp = m.hp;
    if (m.dmg > 0) {
      if (m.stun > t.stun) t.stun = m.stun;
      if (t.ctl) { t.kv.x += m.kx; t.kv.z += m.kz; }
      this.burst(t.pos, 0xff5252, 8, 4); this.sfx('hit');
    } else if (m.dmg < 0) this.burst(t.pos, 0x69f0ae, 6, 2);
    if (m.sid && m.shp) { const s = this.G.players.get(m.sid); if (s) s.hp = m.shp; }
  }

  update(dt) {
    const G = this.G;
    // Đạn
    for (let i = this.proj.length - 1; i >= 0; i--) {
      const q = this.proj[i], s = q.s;
      q.m.position.x += q.vx * s.speed * dt; q.m.position.z += q.vz * s.speed * dt;
      q.life -= dt;
      if (Math.random() < 0.4) this.burst({ x: q.m.position.x, z: q.m.position.z }, s.color || HEROES[q.o.hero].color, 1, 0.5);
      let hit = false;
      if (G.auth) for (const t of this.enemies(q.o)) {
        if (Math.hypot(t.pos.x - q.m.position.x, t.pos.z - q.m.position.z) < s.radius + 0.7) {
          const d = Math.hypot(q.vx, q.vz) || 1;
          this.damage(q.o, t, s.dmg, s, q.vx / d, q.vz / d); hit = true; break;
        }
      }
      if (hit || q.life <= 0) {
        if (hit) this.burst({ x: q.m.position.x, z: q.m.position.z }, s.color || 0xffffff, 8, 4);
        G.scene.remove(q.m); this.proj.splice(i, 1);
      }
    }
    // Sát thương khi lướt (host)
    if (G.auth) for (const p of G.players.values()) {
      const d = p.dash;
      if (!d || !d.sk.dmg || !p.alive) continue;
      for (const t of this.enemies(p)) {
        if (d.hit.has(t.id)) continue;
        if (Math.hypot(t.pos.x - p.pos.x, t.pos.z - p.pos.z) < 1.8) { d.hit.add(t.id); this.damage(p, t, d.sk.dmg, d.sk, d.nx, d.nz); }
      }
    }
    for (const p of G.players.values()) if (p.dash && Math.random() < 0.7) this.burst(p.pos, HEROES[p.hero].color, 1, 1);
    // Hiệu ứng
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]; f.life -= dt;
      if (f.k === 'p') { f.vy -= 12 * dt; f.m.position.x += f.vx * dt; f.m.position.y += f.vy * dt; f.m.position.z += f.vz * dt; if (f.m.position.y < 0.05) f.m.position.y = 0.05; }
      else { const k = 1 - f.life / f.max; f.m.scale.setScalar(f.r * k + 0.1); f.m.material.opacity = 0.8 * (1 - k); }
      if (f.life <= 0) { G.scene.remove(f.m); if (f.k === 'r') f.m.material.dispose(); this.fx.splice(i, 1); }
    }
  }

  reset() {
    for (const q of this.proj) this.G.scene.remove(q.m);
    for (const f of this.fx) { this.G.scene.remove(f.m); if (f.k === 'r') f.m.material.dispose(); }
    this.proj = []; this.fx = [];
  }
}
