// Mỗi tướng: skills[0]=đánh thường, [1..3]=kỹ năng, [4]=tuyệt chiêu (ult)
export const HEROES = {
  knight: {
    name: 'Hiệp Sĩ', role: 'Đỡ đòn', color: 0x4a90e2, hp: 1200, speed: 6.2, dr: 0.15,
    passive: 'Giáp Thép: giảm 15% sát thương nhận.',
    skills: [
      { n: 'Chém', type: 'melee', cd: 0.6, dmg: 70, range: 3.4, arc: 2.2, knock: 3 },
      { n: 'Xung Phong', type: 'dash', cd: 6, dmg: 90, dist: 8, speed: 26, stun: 0.8, knock: 4 },
      { n: 'Tiếng Gầm', type: 'aoe', cd: 9, dmg: 60, radius: 5, stun: 1.3, knock: 5 },
      { n: 'Khiên Thần', type: 'buff', cd: 12, shield: 300, dur: 5, speed: 1.3 },
      { n: 'Phán Xét', type: 'aoe', cd: 35, dmg: 260, radius: 7.5, stun: 1.8, knock: 10, ult: true }
    ]
  },
  mage: {
    name: 'Pháp Sư', role: 'Sát thương xa', color: 0xb36bff, hp: 800, speed: 5.8, regen: 12,
    passive: 'Nội Năng: hồi 12 máu mỗi giây.',
    skills: [
      { n: 'Tia Lửa', type: 'projectile', cd: 0.7, dmg: 55, speed: 22, life: 0.9, radius: 0.35 },
      { n: 'Cầu Lửa', type: 'projectile', cd: 5, dmg: 130, speed: 18, life: 1.1, radius: 0.9, knock: 4, color: 0xff7043 },
      { n: 'Băng Giá', type: 'aoe', cd: 9, dmg: 40, radius: 5, stun: 1.5, knock: 2 },
      { n: 'Dịch Chuyển', type: 'dash', cd: 8, dmg: 0, dist: 8, speed: 60 },
      { n: 'Thiên Thạch', type: 'aoe', cd: 35, dmg: 320, radius: 6, offset: 7, delay: 0.9, stun: 1.2, knock: 7, ult: true }
    ]
  },
  assassin: {
    name: 'Sát Thủ', role: 'Cơ động', color: 0xff4f6d, hp: 850, speed: 7.4, ls: 0.15,
    passive: 'Hút Máu: hồi 15% sát thương gây ra.',
    skills: [
      { n: 'Chém Nhanh', type: 'melee', cd: 0.4, dmg: 45, range: 2.6, arc: 1.6, knock: 1 },
      { n: 'Phi Tiêu', type: 'projectile', cd: 5, dmg: 45, speed: 26, life: 0.7, radius: 0.3, count: 3, spread: 0.3 },
      { n: 'Lướt Kiếm', type: 'dash', cd: 6, dmg: 100, dist: 7, speed: 32 },
      { n: 'Bão Tốc', type: 'buff', cd: 11, speed: 1.7, dur: 3.5 },
      { n: 'Sát Thần', type: 'dash', cd: 32, dmg: 260, dist: 10, speed: 40, stun: 1, ult: true }
    ]
  },
  priest: {
    name: 'Thầy Tế', role: 'Hỗ trợ', color: 0xffe066, hp: 900, speed: 5.9, regen: 8,
    passive: 'Ân Sủng: hồi 8 máu mỗi giây.',
    skills: [
      { n: 'Quang Đạn', type: 'projectile', cd: 0.7, dmg: 40, speed: 20, life: 0.9, radius: 0.35 },
      { n: 'Chùm Sáng', type: 'projectile', cd: 5, dmg: 110, speed: 20, life: 1, radius: 0.9, stun: 0.5, knock: 3 },
      { n: 'Hồi Phục', type: 'heal', cd: 8, amount: 220, radius: 6 },
      { n: 'Trói Buộc', type: 'aoe', cd: 10, dmg: 30, radius: 4.5, offset: 4, stun: 1.8 },
      { n: 'Thánh Quang', type: 'heal', cd: 35, amount: 450, dmg: 150, radius: 9, stun: 0.8, knock: 6, ult: true }
    ]
  }
};
