// PeerJS (WebRTC) – mô hình sao: host làm trọng tài, client gửi trạng thái/skill lên host, host phát lại.
const PREFIX = 'apexhc-';

export class Net {
  constructor() {
    this.peer = null; this.conns = new Map(); this.isHost = false; this.hostConn = null; this.id = null;
    this.onmsg = () => {}; this.onclose = () => {};
  }

  host(code) {
    return new Promise((res, rej) => {
      this.isHost = true; this.id = 'host';
      this.peer = new Peer(PREFIX + code);
      this.peer.on('open', () => res(code));
      this.peer.on('error', rej);
      this.peer.on('connection', c => {
        c.on('open', () => this.conns.set(c.peer, c));
        c.on('data', m => this.onmsg(m, c));
        c.on('close', () => { this.conns.delete(c.peer); this.onclose(c.peer); });
      });
    });
  }

  join(code) {
    return new Promise((res, rej) => {
      const timer = setTimeout(() => rej({ type: 'timeout' }), 9000);
      this.peer = new Peer();
      this.peer.on('error', e => { clearTimeout(timer); rej(e); });
      this.peer.on('open', id => {
        this.id = id;
        const c = this.peer.connect(PREFIX + code, { reliable: true });
        this.hostConn = c;
        c.on('open', () => { clearTimeout(timer); res(id); });
        c.on('data', m => this.onmsg(m, c));
        c.on('close', () => this.onclose('host'));
      });
    });
  }

  // client -> host ; host -> tất cả client
  send(m) {
    if (this.isHost) this.bcast(m);
    else if (this.hostConn && this.hostConn.open) this.hostConn.send(m);
  }

  bcast(m, except) {
    if (!this.isHost) return;
    for (const c of this.conns.values()) if (c !== except && c.open) c.send(m);
  }
}
